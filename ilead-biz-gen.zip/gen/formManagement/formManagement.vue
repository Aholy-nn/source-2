<!--
 * @Description: In User Settings Edit
 * @Author: xx
 * @Date: 2019-09-29 15:36:57
 * @LastEditTime: 2020-06-02 18:59:57
 * @LastEditors: Please set LastEditors
 -->
<template>
  <div class="frame-page">
    <FormManagement />
  </div>
</template>
<script>
// import FormManagement from 'ilead-biz-gen'
export default {
  name: 'formManagement'
//   components: {
//       FormManagement
//   }
}

</script>
<style scoped>
</style>
