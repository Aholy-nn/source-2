<!--
 * @Description: In User Settings Edit
 * @Author: xx
 * @Date: 2019-09-29 15:36:57
 * @LastEditTime: 2020-06-02 18:59:57
 * @LastEditors: Please set LastEditors
 -->
<template>
  <div class="frame-page">
    <FormDesign />
  </div>
</template>
<script>
// import FormDesign from 'ilead-biz-gen'
export default {
  name: 'formDesign'
//   components: {
//       FormDesign
//   }
}

</script>
<style scoped>
</style>
