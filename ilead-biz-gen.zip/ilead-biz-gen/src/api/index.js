/*
 * @Author: your name
 * @Date: 2020-02-04 10:25:36
 * @LastEditTime: 2020-06-02 15:08:15
 * @LastEditors: Please set LastEditors
 * @Description: In User Settings Edit
 * @FilePath: \iLead-ui\ilead4admin-ui\src\views\authui5\user\api\api.js
 */

import http from '@/common/http/api-request.js'

const gen = 'gen/'

export default {
  fetchList: function (query) {
    return http.get(gen + 'generator/page', query)
  },
  fetchDsList: function (query) {
    return http.get(gen + 'dsconf/page', query)
  },
  fetchSelectDsList: function () {
    return http.get(gen + 'dsconf/list')
  },
  addObj: function (param) {
    return http.post(gen + 'dsconf/', param)
  },
  getObj: function (id) {
    return http.get(gen + 'dsconf/' + id)
  },
  delObj: function (id) {
    return http.del(gen + 'dsconf/' + id)
  },
  putObj: function (param) {
    return http.put(gen + 'dsconf/', param)
  },
  preview: function (table) {
    return http.get(gen + 'generator/preview', table)
  },
  handleDown: function (table) {
    return http.post(gen + 'generator/code', table).then((response) => { // 处理返回的文件流
      const blob = new Blob([response.data], {type: 'application/zip'})
      const filename = table.tableName + '.zip'
      const link = document.createElement('a')
      link.href = URL.createObjectURL(blob)
      link.download = filename
      document.body.appendChild(link)
      link.click()
      window.setTimeout(function () {
        URL.revokeObjectURL(blob)
        document.body.removeChild(link)
      }, 0)
    })
  },
  getGenTable: function (query) {
    return http.get(gen + 'generator/table', query)
  },
  getForm: function (tableName, dsName) {
    return http.get(gen + 'form/info', {tableName: tableName, dsName: dsName})
  },
  postForm: function (formInfo, tableName, dsId) {
    return http.post(gen + 'form/', Object.assign({formInfo, tableName, dsId}))
  },
  formFetchList: function (query) {
    return http.get(gen + 'form/page', query)
  },
  formAddObj(obj) {
    return http.post(gen + 'form', obj)
  },
  formGetObj(id) {
    return http.get(gen + 'form/' + id)
  },
  formDelObj(id) {
    return http.del(gen + 'form/' + id)
  },
  formPutObj(obj) {
    return http.put(gen + 'form', obj)
  }
}
