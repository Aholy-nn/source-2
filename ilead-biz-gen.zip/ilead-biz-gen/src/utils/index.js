/*
 * @Author: your name
 * @Date: 2019-12-30 09:26:31
 * @LastEditTime: 2019-12-31 13:30:57
 * @LastEditors: your name
 * @Description: In User Settings Edit
 * @FilePath: \iLead-ui\ilead4admin-ui\src\utils\index.js
 */
import frameUtils from './framework/utils-framework'
export default {
  ...frameUtils
}
