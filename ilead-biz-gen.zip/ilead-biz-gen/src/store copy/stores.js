/*
 * @Author: your name
 * @Date: 2019-12-27 14:01:01
 * @LastEditTime : 2019-12-27 15:12:26
 * @LastEditors  : Please set LastEditors
 * @Description: In User Settings Edit
 * @FilePath: \iLead-ui\ilead4admin-ui\src\store\stores.js
 */
export default {
  state: {
    demo: '测试'
  },
  mutations: {}
}
