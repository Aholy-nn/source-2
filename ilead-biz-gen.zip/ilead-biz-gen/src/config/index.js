/*
 * @Author: your name
 * @Date: 2019-12-31 13:06:06
 * @LastEditTime : 2019-12-31 13:10:33
 * @LastEditors  : Please set LastEditors
 * @Description: In User Settings Edit
 * @FilePath: \iLead-ui\ilead4admin-ui\src\config\index.js
 */
import frameConfig from './framework/config-framework'
export default {
  ...frameConfig
}
