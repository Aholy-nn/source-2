import Vue from 'vue'
import VueRouter from 'vue-router'
import DataSource from '../components/dataSource/dataSource'
import CodeGenerator from '../components/codeGenerator/codeGenerator'
import FormDesign from '../components/formDesign/formDesign'
import FormManagement from '../components/formManagement/formManagement'

Vue.use(VueRouter)

const routes = [
  {
    path: '/',
    name: 'DataSource',
    component: DataSource
  },
  {
    path: '/codeGenerator',
    name: 'CodeGenerator',
    meta: {
      icon: "zvu-icon zvu-icon-ios-paper-outline",
      title: "代码生成"
    },
    component: CodeGenerator
  },
  {
    path: '/formDesign',
    name: 'FormDesign',
    meta: {
      icon: "zvu-icon zvu-icon-ios-paper-outline",
      title: "表单设计"
    },
    component: FormDesign
  },
  {
    path: '/formManagement',
    name: 'FormManagement',
    meta: {
      icon: "zvu-icon zvu-icon-ios-paper-outline",
      title: "表单管理"
    },
    component: FormManagement
  }
]

const router = new VueRouter({
  mode: 'history',
  base: process.env.BASE_URL,
  routes
})

export default router
