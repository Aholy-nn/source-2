import Vue from 'vue'
import App from './App.vue'
import './registerServiceWorker'
import router from './router'
import store from './store'

import ElementUI from 'element-ui'
import 'element-ui/lib/theme-chalk/index.css'
import Avue from '@smallwei/avue';
import '@smallwei/avue/lib/index.css';
import '@/styles/common.scss'
import AvueFormDesign from 'pig-avue-form-design'

Vue.use(ElementUI, {
  size: 'small',
  menuType: 'text'
})
Vue.use(Avue);
Vue.use(AvueFormDesign);

Vue.config.productionTip = false

new Vue({
  router,
  store,
  render: h => h(App)
}).$mount('#app')
